## Place I want to visit - Iceland ##

### Getting started

1. Check out the repository
2. !NAVIGATE TO THE DIST FOLDER!
3. To inspect the site on your phone, you can run a local server

  ```bash
  $> cd /path/to/your-project-folder
  $> python -m SimpleHTTPServer 8080
  ```

4. Open a browser and visit localhost:8080
